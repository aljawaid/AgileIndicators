# AgileIndicators Changelog


## v1.0

### What's Changed

_(most recent changes are listed on top):_
- Initial release
- Plugin Files
- Cleanup code
- Added `en_GB` translations
- Added css and changelog
- Add Readme with screenshots


 [**Full Changelog**](../master/changelog.md "See changes")
